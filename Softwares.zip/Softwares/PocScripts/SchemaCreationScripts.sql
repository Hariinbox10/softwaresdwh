USE [CDTest]
GO
/****** Object:  Schema [CDPrd_Dwh]    Script Date: 9/9/2022 11:57:18 AM ******/
CREATE SCHEMA [CDPrd_Dwh]
GO
/****** Object:  Schema [CDPrd_Stg]    Script Date: 9/9/2022 11:57:18 AM ******/
CREATE SCHEMA [CDPrd_Stg]
GO
