CREATE TABLE CDPrd_Stg.StgSfAccount(
AccountStatusC nvarchar(255)
,AuroraCustomerNoC nvarchar(255)
,AuroraIdC nvarchar(255)
,Id int
,[Name] nvarchar(255)
,PrimaryContactC Numeric(18,0)
,DimensionCheckSum int not null default -1
,LastEtlRun datetime default getdate()
,BatchId int default (CONVERT([varchar],getdate(),(112)))
)


----

CREATE TABLE CDPrd_Stg.StgGetTitanCurrency(
Id int
,Code nvarchar(255)
,[Name] nvarchar(255)
,LastEtlRun datetime default getdate()
,BatchId int default (CONVERT([varchar],getdate(),(112)))
)

---------
CREATE TABLE CDPrd_Stg.StgSfContact(
AccountId nvarchar(255)
,Id int
,FirstName nvarchar(255)
,LastEtlRun datetime default getdate()
,BatchId int default (CONVERT([varchar],getdate(),(112)))
)


------------

CREATE TABLE CDPrd_Stg.StgGetTitanDeal(
Id int
,InstructionNumber nvarchar(255)
,CrmAccountId nvarchar(255)
,SellingCurrency decimal(18,4)
,BuyingCurrency decimal(18,4)
,ValueDate datetime
,SellingAmount decimal(18,4)
,BuyingAmount decimal(18,4)
,Netprofit decimal(18,4)
,LastEtlRun datetime default getdate()
,BatchId int default (CONVERT([varchar],getdate(),(112)))
)

--------------