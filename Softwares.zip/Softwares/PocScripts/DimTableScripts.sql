CREATE TABLE CDPrd_Dwh.DimGetTitanCurrency(
SkCurrencyId int IDENTITY(1,1)
,Id int
,Code nvarchar(255)
,[Name] nvarchar(255)
,LastEtlRun datetime default getdate()
,BatchId int default (CONVERT([varchar],getdate(),(112)))
)
------------

CREATE TABLE CDPrd_Dwh.DimSfAccount(
SkAccountId int IDENTITY(1,1)
,AccountStatusC nvarchar(255)
,AuroraCustomerNoC nvarchar(255)
,AuroraIdC nvarchar(255)
,Id int
,[Name] nvarchar(255)
,PrimaryContactC Numeric(18,0)
,DimensionCheckSum int not null default -1
,EffectiveDate date not null default getdate()
,EndDate date not null default '12/31/9999'
,IsActive bit default 1
,LastEtlRun datetime default getdate()
,BatchId int default (CONVERT([varchar],getdate(),(112)))
)


--------

CREATE TABLE CDPrd_Dwh.DimSfContact(
SkContacttId int IDENTITY(1,1)
,AccountId nvarchar(255)
,Id int
,FirstName nvarchar(255)
,LastEtlRun datetime default getdate()
,BatchId int default (CONVERT([varchar],getdate(),(112)))
)