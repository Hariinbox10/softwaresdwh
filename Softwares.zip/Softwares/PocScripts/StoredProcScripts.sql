USE [CDTest]
GO
/****** Object:  StoredProcedure [CDPrd_Dwh].[USP_SfAccountSCD]    Script Date: 9/9/2022 11:56:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC [CDPrd_Dwh].[USP_SfAccountSCD]

AS

-- Update the checksum value in the staging table
UPDATE [CDPrd_Stg].[StgSfAccount] set DimensionCheckSum=
BINARY_CHECKSUM(PrimaryContactC)

INSERT INTO [CDPrd_Dwh].[DimSfAccount]
(
		 AccountStatusC
		,AuroraCustomerNoC
		,AuroraIdC
		,Id
		,[Name]
		,PrimaryContactC
		,DimensionCheckSum
		,LastEtlRun
		,BatchId
)
SELECT 
		 AccountStatusC
		,AuroraCustomerNoC
		,AuroraIdC
		,Id
		,[Name]
		,PrimaryContactC
		,DimensionCheckSum
		,LastEtlRun
		,BatchId

FROM
(
		MERGE INTO [CDPrd_Dwh].[DimSfAccount] AS TGT

			USING
			(
				SELECT 
				 AccountStatusC
				,AuroraCustomerNoC
				,AuroraIdC
				,Id
				,[Name]
				,PrimaryContactC
				,DimensionCheckSum
				,LastEtlRun
				,BatchId

				FROM [CDPrd_Stg].[StgSfAccount]) AS SRC
				(
				 AccountStatusC
				,AuroraCustomerNoC
				,AuroraIdC
				,Id
				,[Name]
				,PrimaryContactC
				,DimensionCheckSum
				,LastEtlRun
				,BatchId
				) ON
				(
					TGT.AuroraCustomerNoC	=	SRC.AuroraCustomerNoC
				)

				WHEN MATCHED AND TGT.DimensionCheckSum <> SRC.DimensionCheckSum 
												 and TGT.IsActive=1
				THEN 
				UPDATE SET
				TGT.AccountStatusC			=	SRC.AccountStatusC
				,TGT.AuroraIdC				=	SRC.AuroraIdC
				,TGT.Id						=	SRC.Id
				,TGT.[Name]					=	SRC.[Name]
				,TGT.EndDate				=	getdate()
				,TGT.IsActive				=	0
				,TGT.LastEtlRun				=	SRC.LastEtlRun

  
				WHEN NOT MATCHED BY TARGET
					THEN INSERT (
								 AccountStatusC
								,AuroraCustomerNoC
								,AuroraIdC
								,Id
								,[Name]
								,PrimaryContactC
								,DimensionCheckSum
								,LastEtlRun
								,BatchId
								)
						VALUES ( 
								SRC.AccountStatusC
							   ,SRC.AuroraCustomerNoC
							   ,SRC.AuroraIdC
							   ,SRC.Id
							   ,SRC.[Name]
							   ,SRC.PrimaryContactC
							   ,SRC.DimensionCheckSum
							   ,SRC.LastEtlRun
							   ,SRC.BatchId
							  )

						OUTPUT $Action
						,SRC.AccountStatusC
						,SRC.AuroraCustomerNoC
						,SRC.AuroraIdC
						,SRC.Id
						,SRC.[Name]
						,SRC.PrimaryContactC
						,SRC.DimensionCheckSum
						,SRC.LastEtlRun
						,SRC.BatchId
				)

						as changes(
						action
						,AccountStatusC
						,AuroraCustomerNoC
						,AuroraIdC
						,Id
						,[Name]
						,PrimaryContactC
						,DimensionCheckSum
						,LastEtlRun
						,BatchId
						)
						WHERE action = 'UPDATE';

DELETE FROM [CDPrd_Dwh].[DimSfAccount]
WHERE SkAccountId = (SELECT MIN(SkAccountId)
					 FROM [CDPrd_Dwh].[DimSfAccount]
					 GROUP BY AuroraIdC
					 HAVING COUNT(AuroraIdC) > 2)

GO
/****** Object:  StoredProcedure [CDPrd_Dwh].[USP_SfContact]    Script Date: 9/9/2022 11:56:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC [CDPrd_Dwh].[USP_SfContact]

AS
	MERGE CDPrd_Dwh.DimSfContact AS TGT
	USING(SELECT DISTINCT
		   LTRIM(RTRIM(AccountId)) AS AccountId
		  ,LTRIM(RTRIM(Id)) AS Id
		  ,LTRIM(RTRIM(FirstName)) AS FirstName
		  ,LastEtlRun
		  ,BatchId
		  FROM [CDPrd_Stg].[StgSfContact]
		  WHERE AccountId is NOT NULL and AccountId <> '') AS SRC
		  ON (TGT.AccountId = SRC.AccountId)
		     WHEN MATCHED
					THEN UPDATE SET
					TGT.AccountId		=	SRC.AccountId
				   ,TGT.Id				=	SRC.Id
				   ,TGT.FirstName		=	SRC.FirstName
				   ,TGT.LastEtlRun		=	SRC.LastEtlRun
				   ,TGT.BatchId			=	SRC.BatchId
		  
			 WHEN NOT MATCHED BY TARGET
					THEN INSERT (
								 AccountId
								,Id
								,FirstName
								,LastEtlRun
								,BatchId
								)
						VALUES ( SRC.AccountId
								,SRC.Id
								,SRC.FirstName
								,SRC.LastEtlRun
								,SRC.BatchId
								);
GO
/****** Object:  StoredProcedure [CDPrd_Dwh].[USP_TitanCurrency]    Script Date: 9/9/2022 11:56:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC [CDPrd_Dwh].[USP_TitanCurrency]

AS
	MERGE CDPrd_Dwh.DimGetTitanCurrency AS TGT
	USING(SELECT DISTINCT
		   LTRIM(RTRIM(Id)) AS Id
		  ,LTRIM(RTRIM(Code)) AS Code
		  ,LTRIM(RTRIM([Name])) AS [Name]
		  ,LastEtlRun
		  ,BatchId
		  FROM [CDPrd_Stg].[StgGetTitanCurrency]
		  WHERE Id is NOT NULL and Id <> '') AS SRC
		  ON (TGT.ID = SRC.ID)
		     WHEN MATCHED
					THEN UPDATE SET
					TGT.Id				=	SRC.Id
				   ,TGT.Code			=	SRC.Code
				   ,TGT.[Name]			=	SRC.[Name]
				   ,TGT.LastEtlRun		=	SRC.LastEtlRun
				   ,TGT.BatchId			=	SRC.BatchId
		  
			 WHEN NOT MATCHED BY TARGET
					THEN INSERT (
								Id
								,Code
								,[Name]
								,LastEtlRun
								,BatchId
								)
						VALUES (SRC.Id
								,SRC.Code
								,SRC.[Name]
								,SRC.LastEtlRun
								,SRC.BatchId
								);
GO
